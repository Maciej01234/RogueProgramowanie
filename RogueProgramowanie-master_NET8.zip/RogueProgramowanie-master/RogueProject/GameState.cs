﻿namespace ClassesIntro;

public class GameState
{
    public Player Hero { get; private set; }
    public GameBoard Board { get; private set; }
    public Inventory Inventory { get; private set; }
    public List<GameItem> Items { get; private set; }
    public List<Npc> Npcs { get; private set; }
    public string Message { get; set; } = "";

    private Random random = new Random();
    private RandomSpawner spawner;
    private SimpleQuest quest;
    private bool isFinished = false;
    private bool isWin = false;

    public GameState(Player hero)
    {
        Hero = hero;
        Board = new GameBoard();
        Inventory = new Inventory();
        Items = new List<GameItem>();
        Npcs = new List<Npc>();
        spawner = new RandomSpawner(random);
        quest = new SimpleQuest(new MiniGame(random));

        SetupLevel();
    }

    public bool IsFinished()
    {
        return isFinished;
    }

    public bool IsWin()
    {
        return isWin;
    }

    public void SetupLevel()
    {
        Items.Clear();
        Npcs.Clear();
        Board.BuildLevel();
        Hero.SetPosition(new Vector2(4, 2));

        List<Vector2> usedPositions = new List<Vector2>();
        usedPositions.Add(Hero.Position);
        usedPositions.Add(Board.DoorPosition);
        usedPositions.Add(Board.ExitPosition);
        usedPositions.Add(Board.ActionPosition);

        AddRandomItem("Mikstura", "+", ItemType.Potion, usedPositions);
        AddRandomItem("Moneta", "$", ItemType.Coin, usedPositions);
        AddRandomItem("Moneta", "$", ItemType.Coin, usedPositions);

        Vector2 npcPosition = spawner.GetFreePosition(Board.width, Board.height, Board.GetBlockedWalls(), usedPositions);
        usedPositions.Add(npcPosition);
        Npcs.Add(new Npc(npcPosition));

        Message = "Poziom " + Board.level + ": WASD ruch, F podnies, E interakcja, H uzyj mikstury, R wyrzuc.";
    }

    private void AddRandomItem(string name, string avatar, ItemType type, List<Vector2> usedPositions)
    {
        Vector2 position = spawner.GetFreePosition(Board.width, Board.height, Board.GetBlockedWalls(), usedPositions);
        usedPositions.Add(position);
        Items.Add(new GameItem(name, avatar, position, type));
    }

    public void Display()
    {
        Console.Clear();
        Console.SetCursorPosition(0, 0);
        Console.Write("HP: " + Hero.GetHealth() + "  Poziom: " + Board.level);

        Board.Display();

        foreach (GameItem item in Items)
            item.Display();

        foreach (Npc npc in Npcs)
            npc.Display();

        Hero.Display();
        Inventory.Display();

        Console.SetCursorPosition(0, 21);
        Console.Write(Message + "                                                        ");
    }

    public void PickUpItem()
    {
        for (int i = 0; i < Items.Count; i++)
        {
            if (Items[i].position.x == Hero.Position.x && Items[i].position.y == Hero.Position.y)
            {
                Inventory.AddItem(Items[i]);
                Message = "Podniesiono: " + Items[i].name;
                Items.RemoveAt(i);
                return;
            }
        }

        Message = "Nie ma tu przedmiotu.";
    }

    public void UsePotion()
    {
        if (Inventory.UsePotion(Hero))
            Message = "Uzyto mikstury. HP: " + Hero.GetHealth();
        else
            Message = "Nie masz mikstury.";
    }

    public void DropItem()
    {
        GameItem? item = Inventory.DropLastItem(Hero.Position);

        if (item == null)
        {
            Message = "Ekwipunek jest pusty.";
            return;
        }

        Items.Add(item);
        Message = "Wyrzucono: " + item.name;
    }

    public void Interact()
    {
        foreach (Npc npc in Npcs)
        {
            int distanceX = Math.Abs(npc.Position.x - Hero.Position.x);
            int distanceY = Math.Abs(npc.Position.y - Hero.Position.y);

            if (distanceX + distanceY <= 1)
            {
                quest.Interact(Inventory, this);
                return;
            }
        }

        if (Board.IsActionPlace(Hero.Position))
        {
            if (Inventory.HasItem("Krysztal"))
            {
                Inventory.RemoveItem("Krysztal");
                Inventory.AddItem(new GameItem("Klucz", "k", new Vector2(0, 0), ItemType.Key));
                Message = "Oltarz zamienil Krysztal w Klucz. Podejdz do drzwi D.";
            }
            else
            {
                Message = "Tu trzeba uzyc Krysztalu od NPC.";
            }

            return;
        }

        Message = "Nie ma z czym wejsc w interakcje.";
    }

    public bool TryOpenDoor(Vector2 targetPosition)
    {
        if (!Board.IsDoor(targetPosition) || Board.doorOpen)
            return false;

        if (Inventory.HasItem("Klucz"))
        {
            Inventory.RemoveItem("Klucz");
            Board.OpenDoor();
            Message = "Drzwi otwarte. Idz do znaku >.";
            return true;
        }

        Message = "Drzwi sa zamkniete. Potrzebujesz Klucza.";
        return true;
    }

    public void UpdateNpcs()
    {
        foreach (Npc npc in Npcs)
        {
            npc.ChooseAction(Board.GetBlockedWalls());

            if (npc.Position.x == Hero.Position.x && npc.Position.y == Hero.Position.y)
            {
                Hero.TakeDamage(10);
                Message = "NPC cie trafil. Straciles HP.";
            }
        }
    }

    public void CheckEndGame()
    {
        if (Hero.IsDead())
        {
            isFinished = true;
            isWin = false;
            Message = "Przegrana. Postac stracila cale HP.";
            return;
        }

        if (Board.IsExit(Hero.Position))
        {
            if (Board.level == 1)
            {
                if (!Board.doorOpen)
                {
                    Message = "Najpierw otworz drzwi D.";
                    return;
                }

                Board.NextLevel();
                SetupLevel();
                Message = "Przeszedles na nastepna plansze.";
                return;
            }

            isFinished = true;
            isWin = true;
            Message = "Wygrana. Udalo sie przejsc wszystkie plansze.";
        }
    }
}
