﻿namespace ClassesIntro;

public class MiniGame
{
    private Random random;

    public MiniGame(Random random)
    {
        this.random = random;
    }

    public bool Play()
    {
        Console.SetCursorPosition(0, 22);
        Console.Write("Mini gra: 1 kamien, 2 papier, 3 nozyce. Wybierz:                    ");

        ConsoleKeyInfo keyInfo = Console.ReadKey(true);
        int playerChoice = 0;

        if (keyInfo.Key == ConsoleKey.D1 || keyInfo.Key == ConsoleKey.NumPad1)
            playerChoice = 1;
        else if (keyInfo.Key == ConsoleKey.D2 || keyInfo.Key == ConsoleKey.NumPad2)
            playerChoice = 2;
        else if (keyInfo.Key == ConsoleKey.D3 || keyInfo.Key == ConsoleKey.NumPad3)
            playerChoice = 3;

        if (playerChoice == 0)
            return false;

        int npcChoice = random.Next(1, 4);

        if (playerChoice == npcChoice)
            return false;

        if (playerChoice == 1 && npcChoice == 3)
            return true;

        if (playerChoice == 2 && npcChoice == 1)
            return true;

        if (playerChoice == 3 && npcChoice == 2)
            return true;

        return false;
    }
}
