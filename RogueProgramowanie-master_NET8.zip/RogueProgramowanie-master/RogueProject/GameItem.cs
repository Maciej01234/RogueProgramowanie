﻿namespace ClassesIntro;

public enum ItemType
{
    Potion,
    Key,
    Quest,
    Coin
}

public class GameItem
{
    public string name;
    public string avatar;
    public Vector2 position;
    public ItemType type;

    public GameItem(string name, string avatar, Vector2 position, ItemType type)
    {
        this.name = name;
        this.avatar = avatar;
        this.position = position;
        this.type = type;
    }

    public void Display()
    {
        Console.SetCursorPosition(position.x, position.y);
        Console.Write(avatar);
    }
}
