﻿namespace ClassesIntro;

public class SimpleQuest
{
    private bool taskStarted = false;
    private bool taskCompleted = false;
    private MiniGame miniGame;

    public bool TaskCompleted
    {
        get { return taskCompleted; }
    }

    public SimpleQuest(MiniGame miniGame)
    {
        this.miniGame = miniGame;
    }

    public void Interact(Inventory inventory, GameState gameState)
    {
        if (!taskStarted)
        {
            taskStarted = true;
            gameState.Message = "NPC: wygraj mini gre, a dostaniesz krysztal do oltarza.";
            return;
        }

        if (!taskCompleted)
        {
            bool win = miniGame.Play();

            if (win)
            {
                taskCompleted = true;
                inventory.AddItem(new GameItem("Krysztal", "*", new Vector2(0, 0), ItemType.Quest));
                gameState.Message = "Wygrales mini gre. NPC dal ci Krysztal.";
            }
            else
            {
                gameState.Message = "NPC: tym razem przegrales. Sprobuj jeszcze raz.";
            }

            return;
        }

        gameState.Message = "NPC: uzyj Krysztalu przy znaku !";
    }
}
