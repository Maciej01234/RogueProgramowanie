﻿namespace ClassesIntro;

public class RandomSpawner
{
    private Random random;

    public RandomSpawner(Random random)
    {
        this.random = random;
    }

    public Vector2 GetFreePosition(int width, int height, List<Vector2> walls, List<Vector2> usedPositions)
    {
        for (int i = 0; i < 500; i++)
        {
            Vector2 position = new Vector2(random.Next(2, width - 1), random.Next(2, height));

            if (!HasPosition(walls, position) && !HasPosition(usedPositions, position))
                return position;
        }

        for (int y = 2; y < height; y++)
        {
            for (int x = 2; x < width - 1; x++)
            {
                Vector2 position = new Vector2(x, y);

                if (!HasPosition(walls, position) && !HasPosition(usedPositions, position))
                    return position;
            }
        }

        return new Vector2(2, 2);
    }

    private bool HasPosition(List<Vector2> positions, Vector2 targetPosition)
    {
        foreach (Vector2 position in positions)
        {
            if (position.x == targetPosition.x && position.y == targetPosition.y)
                return true;
        }

        return false;
    }
}
