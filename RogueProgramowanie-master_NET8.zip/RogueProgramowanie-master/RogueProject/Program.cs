﻿using ClassesIntro;
// See https://aka.ms/new-console-template for more information
// string playerAvatar = "@";
// Console.WriteLine(playerAvatar);


Console.CursorVisible = false;

Vector2 startingPosition = new Vector2(4, 2);
Player hero = new Player(startingPosition);
GameState gameState = new GameState(hero);

gameState.Display();

while (!gameState.IsFinished())
{
    hero.ChooseAction(gameState);
    gameState.UpdateNpcs();
    gameState.CheckEndGame();
    gameState.Display();
}

Console.SetCursorPosition(0, 23);

if (gameState.IsWin())
    Console.WriteLine("Koniec gry: wygrales!");
else
    Console.WriteLine("Koniec gry: przegrales.");

Console.CursorVisible = true;
Console.ReadKey(true);
