﻿namespace ClassesIntro;

public class GameBoard
{
    public int level = 1;
    public int width = 40;
    public int height = 18;
    public bool doorOpen = false;

    public Vector2 DoorPosition { get; private set; }
    public Vector2 ExitPosition { get; private set; }
    public Vector2 ActionPosition { get; private set; }

    private List<Vector2> walls = new List<Vector2>();

    public GameBoard()
    {
        BuildLevel();
    }

    public void BuildLevel()
    {
        walls.Clear();
        doorOpen = false;

        DoorPosition = new Vector2(26, 8);
        ExitPosition = new Vector2(36, 12);
        ActionPosition = new Vector2(20, 6);

        for (int x = 0; x < width; x++)
        {
            walls.Add(new Vector2(x, 1));
            walls.Add(new Vector2(x, height));
        }

        for (int y = 1; y <= height; y++)
        {
            walls.Add(new Vector2(0, y));
            walls.Add(new Vector2(width, y));
        }

        if (level == 1)
        {
            walls.Add(new Vector2(7, 2));
            walls.Add(new Vector2(8, 2));
            walls.Add(new Vector2(9, 2));
            walls.Add(new Vector2(10, 2));
            walls.Add(new Vector2(11, 2));

            walls.Add(new Vector2(7, 3));
            walls.Add(new Vector2(7, 4));
            walls.Add(new Vector2(7, 5));
            walls.Add(new Vector2(7, 6));

            walls.Add(new Vector2(25, 8));
            walls.Add(new Vector2(27, 8));
            walls.Add(new Vector2(28, 8));
            walls.Add(new Vector2(29, 8));
        }
        else
        {
            doorOpen = true;
            DoorPosition = new Vector2(14, 10);
            ExitPosition = new Vector2(35, 15);
            ActionPosition = new Vector2(22, 8);

            for (int x = 18; x < 30; x++)
                walls.Add(new Vector2(x, 5));

            for (int y = 6; y < 14; y++)
                walls.Add(new Vector2(30, y));
        }
    }

    public void NextLevel()
    {
        level++;
        BuildLevel();
    }

    public List<Vector2> GetBlockedWalls()
    {
        List<Vector2> blockedWalls = new List<Vector2>();

        foreach (Vector2 wall in walls)
            blockedWalls.Add(wall);

        if (!doorOpen)
            blockedWalls.Add(DoorPosition);

        return blockedWalls;
    }

    public bool IsDoor(Vector2 position)
    {
        return position.x == DoorPosition.x && position.y == DoorPosition.y;
    }

    public bool IsExit(Vector2 position)
    {
        return position.x == ExitPosition.x && position.y == ExitPosition.y;
    }

    public bool IsActionPlace(Vector2 position)
    {
        return position.x == ActionPosition.x && position.y == ActionPosition.y;
    }

    public void OpenDoor()
    {
        doorOpen = true;
    }

    public void Display()
    {
        foreach (Vector2 wall in walls)
        {
            Console.SetCursorPosition(wall.x, wall.y);
            Console.Write("#");
        }

        Console.SetCursorPosition(ExitPosition.x, ExitPosition.y);
        Console.Write(">");

        Console.SetCursorPosition(ActionPosition.x, ActionPosition.y);
        Console.Write("!");

        if (!doorOpen)
        {
            Console.SetCursorPosition(DoorPosition.x, DoorPosition.y);
            Console.Write("D");
        }
    }
}
