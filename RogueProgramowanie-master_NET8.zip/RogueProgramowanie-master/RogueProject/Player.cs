﻿namespace ClassesIntro;

public class Player : Character
{
    public Player(Vector2 startingPosition) : base(startingPosition)
    {
    }
    
    public override void ChooseAction(List<Vector2> walls)
    {
        ConsoleKeyInfo keyInfo = Console.ReadKey(true);
        ClearAtPosition();
        
        if(IsDead())
            return;
    
        if (keyInfo.Key == ConsoleKey.A)
        {
            // ruch w lewo
            Move(-1, 0, walls);
        }
        else if (keyInfo.Key == ConsoleKey.D)
        {
            // ruch w prawo
            Move(1, 0, walls);
        }
        else if (keyInfo.Key == ConsoleKey.W)
        {
            // ruch w górę
            Move(0, -1, walls);
        }
        else if (keyInfo.Key == ConsoleKey.S)
        {
            // ruch w dół
            Move(0, 1, walls);
        }
    }

    public void ChooseAction(GameState gameState)
    {
        ConsoleKeyInfo keyInfo = Console.ReadKey(true);
        ClearAtPosition();
        
        if(IsDead())
            return;

        int moveX = 0;
        int moveY = 0;
        bool isMoving = true;

        if (keyInfo.Key == ConsoleKey.A)
        {
            // ruch w lewo
            moveX = -1;
        }
        else if (keyInfo.Key == ConsoleKey.D)
        {
            // ruch w prawo
            moveX = 1;
        }
        else if (keyInfo.Key == ConsoleKey.W)
        {
            // ruch w górę
            moveY = -1;
        }
        else if (keyInfo.Key == ConsoleKey.S)
        {
            // ruch w dół
            moveY = 1;
        }
        else
        {
            isMoving = false;
        }

        if (keyInfo.Key == ConsoleKey.F)
        {
            gameState.PickUpItem();
        }
        else if (keyInfo.Key == ConsoleKey.H)
        {
            gameState.UsePotion();
        }
        else if (keyInfo.Key == ConsoleKey.R)
        {
            gameState.DropItem();
        }
        else if (keyInfo.Key == ConsoleKey.E)
        {
            gameState.Interact();
        }

        if (isMoving)
        {
            Vector2 targetPosition = new Vector2(Position.x + moveX, Position.y + moveY);

            if (gameState.TryOpenDoor(targetPosition))
                return;

            Move(moveX, moveY, gameState.Board.GetBlockedWalls());
        }
    }
}
