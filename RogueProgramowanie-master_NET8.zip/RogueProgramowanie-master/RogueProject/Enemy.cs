﻿namespace ClassesIntro;

public class Npc : Character
{
    private List<Vector2> path;
    private int currentTarget = 0;

    public Npc(Vector2 startingPosition) : base(startingPosition)
    {
        avatar = "E";

        path = new List<Vector2>()
        {
            new Vector2(10, 5),
            new Vector2(15, 5),
            new Vector2(15, 10),
            new Vector2(10, 10)
        };
    }

    public override void ChooseAction(List<Vector2> walls)
    {
        Vector2 target = path[currentTarget];

        if (IsWall(target, walls))
        {
            currentTarget++;

            if (currentTarget >= path.Count)
                currentTarget = 0;

            return;
        }

        int moveX = 0;
        int moveY = 0;

        if (Position.x < target.x)
            moveX = 1;
        else if (Position.x > target.x)
            moveX = -1;
        else if (Position.y < target.y)
            moveY = 1;
        else if (Position.y > target.y)
            moveY = -1;

        Vector2 nextPosition = new Vector2(Position.x + moveX, Position.y + moveY);

        if (IsWall(nextPosition, walls))
        {
            if (moveX != 0 && Position.y != target.y)
            {
                moveX = 0;
                moveY = Position.y < target.y ? 1 : -1;
            }
            else if (moveY != 0 && Position.x != target.x)
            {
                moveY = 0;
                moveX = Position.x < target.x ? 1 : -1;
            }

            nextPosition = new Vector2(Position.x + moveX, Position.y + moveY);

            if (IsWall(nextPosition, walls))
            {
                currentTarget++;

                if (currentTarget >= path.Count)
                    currentTarget = 0;

                return;
            }
        }

        ClearAtPosition();
        Move(moveX, moveY, walls);

        if (Position.x == target.x &&
            Position.y == target.y)
        {
            currentTarget++;

            if (currentTarget >= path.Count)
                currentTarget = 0;
        }
    }

    private bool IsWall(Vector2 targetPosition, List<Vector2> walls)
    {
        foreach (Vector2 wall in walls)
        {
            if (wall.x == targetPosition.x && wall.y == targetPosition.y)
                return true;
        }

        return false;
    }
}
