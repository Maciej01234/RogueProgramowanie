﻿namespace ClassesIntro;

public class Inventory
{
    private List<GameItem> items = new List<GameItem>();

    public void AddItem(GameItem item)
    {
        items.Add(item);
    }

    public bool HasItem(string itemName)
    {
        foreach (GameItem item in items)
        {
            if (item.name == itemName)
                return true;
        }

        return false;
    }

    public bool RemoveItem(string itemName)
    {
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i].name == itemName)
            {
                items.RemoveAt(i);
                return true;
            }
        }

        return false;
    }

    public bool UsePotion(Player player)
    {
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i].type == ItemType.Potion)
            {
                player.Heal(25);
                items.RemoveAt(i);
                return true;
            }
        }

        return false;
    }

    public GameItem? DropLastItem(Vector2 position)
    {
        if (items.Count == 0)
            return null;

        GameItem item = items[items.Count - 1];
        items.RemoveAt(items.Count - 1);
        item.position = position;
        return item;
    }

    public void Display()
    {
        Console.SetCursorPosition(0, 20);
        Console.Write("EQ: ");

        if (items.Count == 0)
        {
            Console.Write("pusty                         ");
            return;
        }

        for (int i = 0; i < items.Count; i++)
        {
            Console.Write(items[i].name);

            if (i < items.Count - 1)
                Console.Write(", ");
        }

        Console.Write("                         ");
    }
}
